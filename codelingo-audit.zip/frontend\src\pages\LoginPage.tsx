import { useState } from "react";
import type { FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { login } from "../services/authService";
import "./LoginPage.css";

export default function LoginPage() {
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    if (!identifier.trim() || !password) {
      setError("Email/username dan password wajib diisi.");
      return;
    }

    setLoading(true);
    try {
      const data = await login({ identifier: identifier.trim(), password });
      localStorage.setItem("token", data.token);
      navigate("/profile", { replace: true });
    } catch (err) {
      if (axios.isAxiosError(err)) {
        if (!err.response) {
          setError("Tidak dapat terhubung ke server. Coba lagi nanti.");
        } else if (err.response.status === 401) {
          setError("Email/username atau password salah.");
        } else {
          setError(err.response.data?.error ?? err.response.data?.message ?? "Terjadi kesalahan. Coba lagi.");
        }
      } else {
        setError("Terjadi kesalahan yang tidak diketahui.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <button className="login-close" aria-label="Tutup" onClick={() => navigate("/")}>
        ✕
      </button>
      <button className="btn btn-outline login-signup" onClick={() => navigate("/register")}>
        SIGN UP
      </button>

      <main className="login-container">
        <h1 className="login-title">Log in</h1>

        <form onSubmit={handleSubmit} noValidate>
          <input
            className="login-input"
            type="text"
            placeholder="Email or username"
            autoComplete="username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
          />

          <div className="password-wrapper">
            <input
              className="login-input"
              type="password"
              placeholder="Password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {/* "Lupa password" belum ada endpoint backend-nya, jadi tombolnya belum ditampilkan */}
          </div>

          {error && <p className="login-error" role="alert">{error}</p>}

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "LOADING..." : "LOG IN"}
          </button>
        </form>

        

        {/* Social login belum ada endpoint backend, jadi sementara disabled */}
        
        
        

        <p className="login-terms">
          By signing in to CodeLingo, you agree to our <strong>Terms</strong> and{" "}
          <strong>Privacy Policy</strong>.
        </p>
      </main>
    </div>
  );
}